package Api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;

public class request {
	private HttpTransport TRANSPORT;
	private GenericUrl url;

	public request(String url) {
		this.url = new GenericUrl(url);

	}

	public request(GenericUrl genericUrl) {
		this.url = genericUrl;
	}
	
	public HttpResponse executar() throws IOException {
		return executar();
	}
	/**
	 * Executa a requisi��o com a URL informada, sendo necess�rio informar os
	 * par�metros do cabe�alho
	 * 
	 * @param cabecalhos Lista mapeada contendo os par�metros do cabe�alho
	 * @return Resposta da requisi��o HTTP
	 * @throws IOException
	 */
	public HttpResponse executar(String nome) throws IOException {
		HttpRequest requisicao = reqFactory().buildGetRequest(url);
		
		HttpResponse resposta = requisicao.execute();
		return resposta;
	}
	
	
	//Metodos padroes
	private HttpTransport transport() {
		if (null == TRANSPORT) {
			TRANSPORT = new NetHttpTransport();
		}
		return TRANSPORT;
	}

	private HttpRequestFactory REQ_FACTORY;

	private HttpRequestFactory reqFactory() {
		if (null == REQ_FACTORY) {
			REQ_FACTORY = transport().createRequestFactory();
		}
		return REQ_FACTORY;
	}
}
