package Api;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;





public class GetInfo {
	private static String nome;
	
	final String token = "<nao_precisa_mas_nao_sei_tirar>";
	String nomePokemon = nome;
	String url = String.format("https://pokeapi.co/api/v2/pokemon/%s", nomePokemon);
	request api = new request(url);
	
	
	try {
		JSONObject json = JsonParser.parseToObject(api.executar());
	} catch (IOException e1) {
		
		e1.printStackTrace();
	}
	
}
