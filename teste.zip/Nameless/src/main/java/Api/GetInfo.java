package Api;

import java.io.IOException;

import javax.swing.JComponent;
import javax.swing.JLabel;
import org.json.JSONObject;
import Api.Request;
import Api.JsonParser;;

public class GetInfo {

	private JComponent nomePokemon;
	private JComponent Peso;
	private JComponent Altura;
	private JComponent ID;
	private JComponent isDefault;

	public GetInfo(String nome) throws IOException {
		String url = String.format("https://pokeapi.co/api/v2/pokemon/%s", nome);
		Request api = new Request(url);
		JSONObject item = JsonParser.parseToObject(api.executar());

		nomePokemon = new JLabel("Nome: \n" + item.getString("name"));
		nomePokemon.setBounds(50, 0, 200, 50);

		Peso = new JLabel("\nPeso: \n" + item.getInt("weight"));
		Peso.setBounds(50, 25, 200, 70);

		Altura = new JLabel("\nAltura: \n" + item.getInt("height"));
		Altura.setBounds(50, 50, 200, 70);

		ID = new JLabel("\niD: \n" + item.getInt("id"));
		ID.setBounds(50, 75, 200, 70);

		isDefault = new JLabel("\nis_default: \n" + item.getBoolean("is_default"));
		isDefault.setBounds(50, 100, 200, 70);

	}
	
	public void clear() {
		nomePokemon = new JLabel("");
		nomePokemon.setBounds(50, 0, 200, 50);

		Peso = new JLabel("");
		Peso.setBounds(50, 25, 200, 70);

		Altura = new JLabel("");
		Altura.setBounds(50, 50, 200, 70);

		ID = new JLabel("");
		ID.setBounds(50, 75, 200, 70);

		isDefault = new JLabel("");
		isDefault.setBounds(50, 100, 200, 70);
	}
	

	public JComponent getNomePokemon() {
		return nomePokemon;
	}

	public void setNomePokemon(JComponent nomePokemon) {
		this.nomePokemon = nomePokemon;
	}

	public JComponent getPeso() {
		return Peso;
	}

	public void setPeso(JComponent peso) {
		Peso = peso;
	}

	public JComponent getAltura() {
		return Altura;
	}

	public void setAltura(JComponent altura) {
		Altura = altura;
	}

	public JComponent getID() {
		return ID;
	}

	public void setID(JComponent iD) {
		ID = iD;
	}

	public JComponent getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(JComponent isDefault) {
		this.isDefault = isDefault;
	}

}
