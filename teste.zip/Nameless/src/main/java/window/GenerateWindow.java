package window;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import Api.GetInfo;


public class GenerateWindow {

	private static String texto;

	public static void criarJanela() {
		final JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setBounds(30, 15, 500, 500);
		final JFrame janela = new JFrame();
		janela.setBounds(50, 50, 1200, 900);
		final JTextField busca = new JTextField();
		busca.setBounds(10, 800, 800, 30);
		final JButton botao = new JButton("Pesquisar");
		botao.setBounds(850, 800, 100, 30);
		final JButton botao2 = new JButton("voltar");
		botao2.setBounds(1000, 800, 100, 30);

		botao.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				texto = busca.getText();
				try {
					
					final GetInfo info = new GetInfo(texto);
					panel.add(info.getNomePokemon());
					panel.add(info.getAltura());
					panel.add(info.getPeso());
					panel.add(info.getID());
					panel.add(info.getIsDefault());
					janela.add(panel);
					janela.revalidate();
					janela.repaint();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		botao2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				panel.validate();
				panel.updateUI();
				
			}
		});

		janela.add(busca);
		janela.add(botao);
		janela.add(botao2);
		janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		janela.setLayout(null);
		janela.setVisible(true);
	}

}
