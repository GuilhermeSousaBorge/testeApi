package window;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.json.JSONObject;

import Api.GetInfo;
import Api.JsonParser;
import Api.request;


public class GenerateWindow{
	
	
	
	public static void criarJanela() {
		JFrame janela = new JFrame();
		janela.setBounds(50, 50, 1200, 900);
		final JTextField busca = new JTextField();
		busca.setBounds(10, 800, 800, 30);
		JButton botao = new JButton("Pesquisar");
		botao.setBounds(850, 800, 100, 30);
		
		botao.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		janela.add(busca);
		janela.add(botao);
		janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		janela.setLayout(null);
		janela.setVisible(true);
	}
	
}
