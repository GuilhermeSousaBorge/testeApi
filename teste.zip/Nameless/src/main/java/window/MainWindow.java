package window;

public class MainWindow extends GenerateWindow{
	
	public static void main(String[] args){
		criarJanela();

	}

}
